java -jar JavaRPG.jar
